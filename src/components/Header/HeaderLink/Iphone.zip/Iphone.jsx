import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Iphone() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch("http://localhost:1234/iPhone");
        const data = await response.json();

        // Ensure correct data structure
        setProducts(data.products);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchProducts();
  }, []);

  let flip = false;
  return (
    <div>
      <section className="internal-page-wrapper">
        <div className="container">
          <div className="row justify-content-center text-center">
            <div className="col-12 mt-5">
              <h1 className="fw-bold mt-4">iPhone</h1>
              <div className="fs-4 mb-2">The best for the brightness</div>
            </div>
          </div>
        </div>

        <div className="container">
          <div className="row justify-content-center">
            {products.map((product, index) => {
              // console.log("Product Data:", product);

              const order2 = flip ? 1 : 2;
              const order1 = flip ? 2 : 1;
              flip = !flip;

              return (
                <div
                  key={product.product_url}
                  className="justify-content-center text-center row  "
                >
                  <div
                    className={`col-sm-12 col-md-6 order-${order2} mt-3  d-flex align-items-center  justify-content-center`}
                  >
                    <div>
                      <h5 className="card-title fs-4 ">
                        {product.product_name}
                      </h5>
                      <p className="card-text">
                        {product.Product_brief_description}
                      </p>
                      <h6 className="text-muted">{`Starting at ${product.Starting_price}`}</h6>
                      <p className="text-muted">{product.Price_range}</p>
                      <div className="mt-3">
                        <Link
                          to={`/iPhone/${product.Product_id}`}
                          className="btn btn-primary"
                        >
                          Learn More
                        </Link>
                      </div>
                    </div>
                  </div>
                  <div
                    className={`col-sm-12 col-md-6 order-${order1} d-flex justify-content-center mt-3`}
                  >
                    <div className="product-image  w-50 h-50 ">
                      <img src={product.Product_img} className="img-fluid" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Iphone;
